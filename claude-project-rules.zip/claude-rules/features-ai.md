# Features (AI-Optimized)

**Person:** PersonFlowViewModel, relationship→dates, custom labels, contact+SMS import
**Gift:** PriceRecord tracking, AIService suggestions, OCR import, budget alerts
**Integrations:** Gemini API (GEMINI_API_KEY), CamelCamelCamel, ML Kit, contacts