# Roadmap (AI-Optimized)

**Epics 4-8:** Event mgmt, browse by occasion, AI budget picker, price comparison, security/settings

**Incomplete:** Share intent nav, full file import (CSV only), AI SMS summarization (stubbed)

**Future:** Enhanced AI prompts, more price APIs, file processing (PDF/Doc/Excel), biometric auth, data encryption