# Config (AI-Optimized)

local.properties: `GEMINI_API_KEY=...` `AI_ENABLED=true`
Permissions: READ_SMS, READ_EXTERNAL_STORAGE, READ_CONTACTS