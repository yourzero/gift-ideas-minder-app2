# Workflows (AI-Optimized)

**Entity:** data/model/→dao/→AppDatabase+version→repository/→di/RepositoryModule→ViewModels
**Screen:** ui/screens/→AppNavGraph→ViewModel→nav calls
**DB Change:** AppDatabase version++→migration (prod) or destructive (dev)→TypeConverters